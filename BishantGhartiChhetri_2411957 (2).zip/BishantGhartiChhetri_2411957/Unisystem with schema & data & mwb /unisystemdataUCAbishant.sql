USE unisystem; -- Switch to using the 'unisystem' schema.

-- Table structure for table `student`
CREATE TABLE student (
  student_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing student ID.
  first_name VARCHAR(50) NOT NULL, -- First name of the student.
  last_name VARCHAR(50) NOT NULL, -- Last name of the student.
  dateofbirth DATE NOT NULL, -- Date of birth of the student.
  gender ENUM('M', 'F') NOT NULL, -- Gender of the student (M for male, F for female).
  enrollmentdate DATE NOT NULL, -- Enrollment date of the student.
  PRIMARY KEY (student_id), -- Set student_id as the primary key.
  KEY idx_student_last_name (last_name) -- Add an index on the last_name column.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -- Use InnoDB engine with UTF-8 charset.

-- Table structure for table `teacher`
CREATE TABLE teacher (
  teacher_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing teacher ID.
  first_name VARCHAR(50) NOT NULL, -- First name of the teacher.
  last_name VARCHAR(50) NOT NULL, -- Last name of the teacher.
  dateofbirth DATE NOT NULL, -- Date of birth of the teacher.
  gender ENUM('M', 'F') NOT NULL, -- Gender of the teacher (M for male, F for female).
  hiredate DATE NOT NULL, -- Hire date of the teacher.
  PRIMARY KEY (teacher_id), -- Set teacher_id as the primary key.
  KEY idx_teacher_last_name (last_name) -- Add an index on the last_name column.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -- Use InnoDB engine with UTF-8 charset.

-- Table structure for table `department`
CREATE TABLE department (
  department_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing department ID.
  department_name VARCHAR(100) NOT NULL, -- Name of the department.
  PRIMARY KEY (department_id) -- Set department_id as the primary key.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -- Use InnoDB engine with UTF-8 charset.

-- Table structure for table `courses`
CREATE TABLE courses (
  course_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing course ID.
  course_name VARCHAR(100) NOT NULL, -- Name of the course.
  teacher_id SMALLINT UNSIGNED NOT NULL, -- Foreign key referencing teacher_id in teacher table.
  department_id INT UNSIGNED NOT NULL, -- Foreign key referencing department_id in department table.
  PRIMARY KEY (course_id), -- Set course_id as the primary key.
  KEY idx_teacher_id (teacher_id), -- Add an index on teacher_id.
  KEY idx_department_id (department_id), -- Add an index on department_id.
  CONSTRAINT fk_courses_teacher FOREIGN KEY (teacher_id) REFERENCES teacher (teacher_id)
    ON DELETE CASCADE ON UPDATE CASCADE, -- Define foreign key constraint for teacher_id.
  CONSTRAINT fk_courses_department FOREIGN KEY (department_id) REFERENCES department (department_id)
    ON DELETE CASCADE ON UPDATE CASCADE -- Define foreign key constraint for department_id.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -- Use InnoDB engine with UTF-8 charset.
CREATE TABLE restaurant_dishes (
  dish_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing dish ID.
  dish_name VARCHAR(100) NOT NULL, -- Name of the dish.
  price DECIMAL(10, 2) NOT NULL, -- Price of the dish.
  temperature ENUM('Hot', 'Cold') NOT NULL, -- Temperature of the dish.
  PRIMARY KEY (dish_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for library books
CREATE TABLE library_books (
  book_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing book ID.
  title VARCHAR(200) NOT NULL, -- Title of the book.
  author VARCHAR(100) NOT NULL, -- Author of the book.
  publication_date DATE NOT NULL, -- Date of publication.
  PRIMARY KEY (book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for equipment management
CREATE TABLE equipment_management (
  equipment_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing equipment ID.
  equipment_name VARCHAR(100) NOT NULL, -- Name of the equipment.
  equipment_number VARCHAR(50) NOT NULL, -- Equipment number or serial number.
  lender_id SMALLINT UNSIGNED NOT NULL, -- Foreign key referencing student or teacher.
  PRIMARY KEY (equipment_id),
  CONSTRAINT fk_equipment_lender FOREIGN KEY (lender_id) REFERENCES student (student_id) -- Example foreign key reference to the student table.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for course selection system
CREATE TABLE course_selection (
  selection_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing selection ID.
  student_id SMALLINT UNSIGNED NOT NULL, -- Foreign key referencing student ID.
  course_id SMALLINT UNSIGNED NOT NULL, -- Foreign key referencing course ID.
  PRIMARY KEY (selection_id),
  CONSTRAINT fk_course_selection_student FOREIGN KEY (student_id) REFERENCES student (student_id),
  CONSTRAINT fk_course_selection_course FOREIGN KEY (course_id) REFERENCES courses (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;