SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0; -- Disable unique checks temporarily.
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0; -- Disable foreign key checks temporarily.
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL'; -- Set SQL mode to 'TRADITIONAL'.

DROP SCHEMA IF EXISTS unisystem; -- Drop the schema if it already exists.
CREATE SCHEMA unisystem; -- Create a new schema named 'unisyshost_summary_by_statement_latencyhost_summaryhost_summary_by_stageshost_summarysys_configsys_configsys_configtem'.
USE unisystem; -- Switch to using the 'unisystem' schema.

-- Table structure for table `student`
CREATE TABLE student (
  student_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing student ID.
  first_name VARCHAR(50) NOT NULL, -- First name of the student.
  last_name VARCHAR(50) NOT NULL, -- Last name of the student.
  dateofbirth DATE NOT NULL, -- Date of birth of the student.
  gender ENUM('M', 'F') NOT NULL, -- Gender of the student (M for male, F for female).
  enrollmentdate DATE NOT NULL, -- Enrollment date of the student.
  PRIMARY KEY (student_id), -- Set student_id as the primary key.
  KEY idx_student_last_name (last_name) -- Add an index on the last_name column.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -- Use InnoDB engine with UTF-8 charset.

-- Table structure for table `teacher`
CREATE TABLE teacher (
  teacher_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing teacher ID.
  first_name VARCHAR(50) NOT NULL, -- First name of the teacher.
  last_name VARCHAR(50) NOT NULL, -- Last name of the teacher.
  dateofbirth DATE NOT NULL, -- Date of birth of the teacher.
  gender ENUM('M', 'F') NOT NULL, -- Gender of the teacher (M for male, F for female).
  hiredate DATE NOT NULL, -- Hire date of the teacher.
  PRIMARY KEY (teacher_id), -- Set teacher_id as the primary key.
  KEY idx_teacher_last_name (last_name) -- Add an index on the last_name column.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -- Use InnoDB engine with UTF-8 charset.

-- Table structure for table `department`
CREATE TABLE department (
  department_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing department ID.
  department_name VARCHAR(100) NOT NULL, -- Name of the department.
  PRIMARY KEY (department_id) -- Set department_id as the primary key.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -- Use InnoDB engine with UTF-8 charset.

-- Table structure for table `courses`
CREATE TABLE courses (
  course_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing course ID.
  course_name VARCHAR(100) NOT NULL, -- Name of the course.
  teacher_id SMALLINT UNSIGNED NOT NULL, -- Foreign key referencing teacher_id in teacher table.
  department_id INT UNSIGNED NOT NULL, -- Foreign key referencing department_id in department table.
  PRIMARY KEY (course_id), -- Set course_id as the primary key.
  KEY idx_teacher_id (teacher_id), -- Add an index on teacher_id.
  KEY idx_department_id (department_id), -- Add an index on department_id.
  CONSTRAINT fk_courses_teacher FOREIGN KEY (teacher_id) REFERENCES teacher (teacher_id)
    ON DELETE CASCADE ON UPDATE CASCADE, -- Define foreign key constraint for teacher_id.
  CONSTRAINT fk_courses_department FOREIGN KEY (department_id) REFERENCES department (department_id)
    ON DELETE CASCADE ON UPDATE CASCADE -- Define foreign key constraint for department_id.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -- Use InnoDB engine with UTF-8 charset.
CREATE TABLE restaurant_dishes (
  dish_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing dish ID.
  dish_name VARCHAR(100) NOT NULL, -- Name of the dish.
  price DECIMAL(10, 2) NOT NULL, -- Price of the dish.
  temperature ENUM('Hot', 'Cold') NOT NULL, -- Temperature of the dish.
  PRIMARY KEY (dish_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for library books
CREATE TABLE library_books (
  book_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing book ID.
  title VARCHAR(200) NOT NULL, -- Title of the book.
  author VARCHAR(100) NOT NULL, -- Author of the book.
  publication_date DATE NOT NULL, -- Date of publication.
  PRIMARY KEY (book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for equipment management
CREATE TABLE equipment_management (
  equipment_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing equipment ID.
  equipment_name VARCHAR(100) NOT NULL, -- Name of the equipment.
  equipment_number VARCHAR(50) NOT NULL, -- Equipment number or serial number.
  lender_id SMALLINT UNSIGNED NOT NULL, -- Foreign key referencing student or teacher.
  PRIMARY KEY (equipment_id),
  CONSTRAINT fk_equipment_lender FOREIGN KEY (lender_id) REFERENCES student (student_id) -- Example foreign key reference to the student table.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for course selection system
CREATE TABLE course_selection (
  selection_id INT UNSIGNED NOT NULL AUTO_INCREMENT, -- Primary key, auto-incrementing selection ID.
  student_id SMALLINT UNSIGNED NOT NULL, -- Foreign key referencing student ID.
  course_id SMALLINT UNSIGNED NOT NULL, -- Foreign key referencing course ID.
  PRIMARY KEY (selection_id),
  CONSTRAINT fk_course_selection_student FOREIGN KEY (student_id) REFERENCES student (student_id),
  CONSTRAINT fk_course_selection_course FOREIGN KEY (course_id) REFERENCES courses (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

USE unisystem; -- Switch to the 'unisystem' database.

-- Insert data into the student table
INSERT INTO student (first_name, last_name, dateofbirth, gender, enrollmentdate) VALUES
('John', 'Doe', '2000-01-01', 'M', '2018-09-01'), -- Insert student John Doe.
('Jane', 'Smith', '2001-02-02', 'F', '2019-09-01'), -- Insert student Jane Smith.
('Michael', 'Johnson', '2002-03-03', 'M', '2020-09-01'), -- Insert student Michael Johnson.
('Emily', 'Davis', '2000-04-04', 'F', '2018-09-01'), -- Insert student Emily Davis.
('Chris', 'Miller', '2001-05-05', 'M', '2019-09-01'), -- Insert student Chris Miller.
('Anna', 'Wilson', '2002-06-06', 'F', '2020-09-01'), -- Insert student Anna Wilson.
('David', 'Moore', '2000-07-07', 'M', '2018-09-01'), -- Insert student David Moore.
('Jessica', 'Taylor', '2001-08-08', 'F', '2019-09-01'), -- Insert student Jessica Taylor.
('James', 'Anderson', '2002-09-09', 'M', '2020-09-01'), -- Insert student James Anderson.
('Laura', 'Thomas', '2000-10-10', 'F', '2018-09-01'); -- Insert student Laura Thomas.

-- Insert data into the teacher table
INSERT INTO teacher (first_name, last_name, dateofbirth, gender, hiredate) VALUES
('Robert', 'Brown', '1980-01-01', 'M', '2005-08-15'), -- Insert teacher Robert Brown.
('Mary', 'Jones', '1981-02-02', 'F', '2006-08-15'), -- Insert teacher Mary Jones.
('William', 'Garcia', '1982-03-03', 'M', '2007-08-15'), -- Insert teacher William Garcia.
('Patricia', 'Martinez', '1980-04-04', 'F', '2005-08-15'), -- Insert teacher Patricia Martinez.
('Charles', 'Rodriguez', '1981-05-05', 'M', '2006-08-15'), -- Insert teacher Charles Rodriguez.
('Linda', 'Hernandez', '1982-06-06', 'F', '2007-08-15'), -- Insert teacher Linda Hernandez.
('Thomas', 'Lopez', '1980-07-07', 'M', '2005-08-15'), -- Insert teacher Thomas Lopez.
('Barbara', 'Gonzalez', '1981-08-08', 'F', '2006-08-15'), -- Insert teacher Barbara Gonzalez.
('Joseph', 'Wilson', '1982-09-09', 'M', '2007-08-15'), -- Insert teacher Joseph Wilson.
('Susan', 'Anderson', '1980-10-10', 'F', '2005-08-15'); -- Insert teacher Susan Anderson.

-- Insert data into the department table
INSERT INTO department (department_name) VALUES
('Computer Science'), -- Insert Computer Science department.
('Mathematics'), -- Insert Mathematics department.
('Physics'), -- Insert Physics department.
('Chemistry'), -- Insert Chemistry department.
('Biology'), -- Insert Biology department.
('English'), -- Insert English department.
('History'), -- Insert History department.
('Geography'), -- Insert Geography department.
('Philosophy'), -- Insert Philosophy department.
('Economics'); -- Insert Economics department.

-- Insert data into the courses table
INSERT INTO courses (course_name, teacher_id, department_id) VALUES
('Introduction to Programming', 1, 1), -- Assign Introduction to Programming to teacher 1 and department 1.
('Calculus I', 2, 2), -- Assign Calculus I to teacher 2 and department 2.
('General Physics', 3, 3), -- Assign General Physics to teacher 3 and department 3.
('Organic Chemistry', 4, 4), -- Assign Organic Chemistry to teacher 4 and department 4.
('Biology 101', 5, 5), -- Assign Biology 101 to teacher 5 and department 5.
('English Literature', 6, 6), -- Assign English Literature to teacher 6 and department 6.
('World History', 7, 7), -- Assign World History to teacher 7 and department 7.
('Geography Basics', 8, 8), -- Assign Geography Basics to teacher 8 and department 8.
('Philosophical Thoughts', 9, 9), -- Assign Philosophical Thoughts to teacher 9 and department 9.
('Microeconomics', 10, 10); -- Assign Microeconomics to teacher 10 and department 10.

-- Insert data into the restaurant_dishes table
INSERT INTO restaurant_dishes (dish_name, price, temperature) VALUES
('Momo', 11.30, 'Hot'), -- Insert Momo.
('Chicken curry', 8.75, 'Hot'), -- Insert Chicken Curry.
('Grilled Burger', 13.00, 'Hot'), -- Insert Grilled Burger.
('Vegetarian Burger', 10.00, 'Hot'), -- Insert Vegetarian Burger.
('Donuts', 5.80, 'HOt'), -- Insert Donuts.
('Tomato Soup', 4.00, 'Hot'), -- Insert Tomato Soup.
('Potato fry', 2.00, 'Hot'), -- Insert Potato fry.
('Noddels', 6.00, 'Hot'), -- Insert Noddels.
('Chicken Paratha', 8.50, 'Cold'), -- Insert Chicken paratha.
('Cocolate cream', 5.00, 'Cold'); -- Insert Cocolate cream.

-- Insert data into the library_books table
INSERT INTO library_books (title, author, publication_date) VALUES
('Introduction to Flowchart', 'Donald Lue', '2007-03-31'), -- Insert Introduction to Flowchart.
('The Munamadan', 'Ram chhetri', '1925-01-12'), -- Insert The Munamadan.
('1990', 'Bimsen thapa', '1991-05-01'), -- Insert 1990.
('To depth of everest', 'Chhetri', '1969-02-01'), -- Insert To depth of everest.
('Pride of Nepal', 'Bishant', '1911-05-15'), -- Insert Pride of Nepal.
('The Untold story of King Mahendra', 'james', '1951-06-12'), -- Insert The Untold story of King Mahendra.
('The Catcheing fish', 'C.A Serbey', '2001-02-19'), -- Insert The Catcheing fish.
('The Shadow', 'B.G.C. Chhetri', '1891-11-13'), -- Insert The Shadow.
('The Lord Buddha', 'Xing yung', '1554-02-19'), -- Insert The Lord Buddha.
('The Program Code', 'Jhon', '1805-05-14'); -- Insert The Program Code.

-- Insert data into the equipment_management table
INSERT INTO equipment_management (equipment_name, equipment_number, lender_id) VALUES
('Laptop', 'K12345', 1), -- Insert Laptop with serial number K12345 lent by student with ID 1.
('Projector', 'D67890', 2), -- Insert Projector with serial number D67890 lent by student with ID 2.
('Microscope', 'L11223', 3), -- Insert Microscope with serial number L11223 lent by student with ID 3.
('Camera', 'Q44556', 4), -- Insert Camera with serial number Q44556 lent by student with ID 4.
('Whiteboard Marker', 'P78901', 5), -- Insert Whiteboard Marker with serial number P78901 lent by student with ID 5.
('Tablet', 'N23456', 6), -- Insert Tablet with serial number N23456 lent by student with ID 6.
('Printer', 'R98765', 7), -- Insert Printer with serial number R98765 lent by student with ID 7.
('Scanner', 'F54321', 8), -- Insert Scanner with serial number F54321 lent by student with ID 8.
('External Hard Drive', 'Z99887', 9), -- Insert External Hard Drive with serial number Z99887 lent by student with ID 9.
('Keyboard', 'U11234', 10); -- Insert Keyboard with serial number U11234 lent by student with ID 10.

-- Insert data into the course_selection table
INSERT INTO course_selection (student_id, course_id) VALUES
(1, 1), -- Student 1 (John Doe) selects course 1 (Introduction to Data and Database).
(2, 2), -- Student 2 (Jane Smith) selects course 2 (Important of Flowchart).
(3, 3), -- Student 3 (Michael Johnson) selects course 3 (Physics).
(4, 4), -- Student 4 (Emily Davis) selects course 4 (Chemistry).
(5, 5), -- Student 5 (Chris Miller) selects course 5 (Biology).
(6, 6), -- Student 6 (Anna Wilson) selects course 6 (GUI).
(7, 7), -- Student 7 (David Moore) selects course 7 (World History).
(8, 8), -- Student 8 (Jessica Taylor) selects course 8 (Geography).
(9, 9), -- Student 9 (James Anderson) selects course 9 (Atomic Plant).
(10, 10); -- Student 10 (Laura Thomas) selects course 10 (economics).

SET SQL_MODE=@OLD_SQL_MODE; -- Restore the original SQL mode.
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS; -- Restore the original foreign key checks.
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS; -- Restore the original unique checks.